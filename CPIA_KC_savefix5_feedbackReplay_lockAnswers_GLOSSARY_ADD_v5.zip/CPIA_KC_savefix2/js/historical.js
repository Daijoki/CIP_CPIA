/**
 * Historical Foundations Manager - Accurate Mappings Version
 */

class HistoricalManager {
    constructor() {
        this.data = null;
        this.urls = null;
        this.browseMode = 'case';
        this.contentContainer = document.getElementById('historical-scenarios');
        this.detailContainer = document.getElementById('historical-connection');
        this.detailContent = document.getElementById('connection-content');
        this.detailContentWrapper = document.getElementById('historical-detail-content');
        
        // Modal elements
        this.modal = document.getElementById('historical-modal');
        this.modalBody = document.getElementById('historical-modal-body');
        this.modalClose = document.getElementById('historical-modal-close');
        this.lastFocusedElement = null;
        
        // Setup modal event listeners
        this.setupModalListeners();
        
        // Carefully mapped cause-effect relationships
        this.caseConnections = {
  "russell-burch-3rs-1959": {
    "0": {
      "lessons": [
        0
      ],
      "regulations": [
        0,
        1
      ]
    },
    "1": {
      "lessons": [
        1
      ],
      "regulations": [
        1
      ]
    }
  },
  "aaalac-founding-1965": {
    "0": {
      "lessons": [
        0
      ],
      "regulations": [
        0,
        1
      ]
    },
    "1": {
      "lessons": [
        1
      ],
      "regulations": [
        1
      ]
    }
  },
  "awa-original-1966": {
    "0": {
      "lessons": [
        0
      ],
      "regulations": [
        0,
        1
      ]
    },
    "1": {
      "lessons": [
        1
      ],
      "regulations": [
        2
      ]
    },
    "2": {
      "lessons": [
        2
      ],
      "regulations": [
        3
      ]
    }
  },
  "phs-policy-1971-1986": {
    "0": {
      "lessons": [
        0
      ],
      "regulations": [
        0
      ]
    },
    "1": {
      "lessons": [
        1
      ],
      "regulations": [
        0,
        1
      ]
    }
  },
  "silver-spring-monkeys-1981": {
    "0": {
      "lessons": [
        0
      ],
      "regulations": [
        0,
        3
      ]
    },
    "1": {
      "lessons": [
        1
      ],
      "regulations": [
        1
      ]
    },
    "2": {
      "lessons": [
        2
      ],
      "regulations": [
        2
      ]
    }
  },
  "penn-head-injury-lab-1984": {
    "0": {
      "lessons": [
        0
      ],
      "regulations": [
        0
      ]
    },
    "1": {
      "lessons": [
        1
      ],
      "regulations": [
        1,
        2
      ]
    }
  },
  "awa-1985-amendments": {
    "0": {
      "lessons": [
        0
      ],
      "regulations": [
        0
      ]
    },
    "1": {
      "lessons": [
        1
      ],
      "regulations": [
        1
      ]
    },
    "2": {
      "lessons": [
        2
      ],
      "regulations": [
        2,
        3
      ]
    }
  },
  "hrea-1985": {
    "0": {
      "lessons": [
        0
      ],
      "regulations": [
        0
      ]
    },
    "1": {
      "lessons": [
        1
      ],
      "regulations": [
        1
      ]
    }
  },
  "guide-2011": {
    "0": {
      "lessons": [
        0
      ],
      "regulations": [
        0
      ]
    },
    "1": {
      "lessons": [
        1
      ],
      "regulations": [
        1
      ]
    }
  },
  "us-surgical-training-1980s-1990s": {
    "0": {
      "lessons": [
        0
      ],
      "regulations": [
        0
      ]
    },
    "1": {
      "lessons": [
        1
      ],
      "regulations": [
        1
      ]
    }
  },
  "columbia-suspension-1988": {
    "0": {
      "lessons": [
        0
      ],
      "regulations": [
        0
      ]
    },
    "1": {
      "lessons": [
        1
      ],
      "regulations": [
        1
      ]
    }
  },
  "chimp-act-2000": {
    "0": {
      "lessons": [
        0
      ],
      "regulations": [
        0
      ]
    },
    "1": {
      "lessons": [
        1
      ],
      "regulations": [
        1
      ]
    }
  },
  "species-specific-welfare-advances-1990s-2010s": {
    "0": {
      "lessons": [
        0
      ],
      "regulations": [
        0
      ]
    },
    "1": {
      "lessons": [
        1
      ],
      "regulations": [
        1
      ]
    }
  },
  "transit-and-field-studies-oversight-1990s-2010s": {
    "0": {
      "lessons": [
        0
      ],
      "regulations": [
        0,
        1
      ]
    },
    "1": {
      "lessons": [
        1
      ],
      "regulations": [
        2
      ]
    }
  }
};
    }
    
    async init() {
        this.showLoading();
        
        try {
            this.data = await DataLoader.getHistoricalFoundations();
            this.urls = await DataLoader.getHistoricalFoundationsUrls();
            
            if (!this.data || !this.data.historical_cases || !this.data.themes) {
                throw new Error('Invalid historical foundations data structure');
            }
            
            if (!this.urls) {
                console.warn('Failed to load historical foundations URLs - citations will not be clickable');
                this.urls = {};
            }
            
            this.renderBrowseModeSelector();
            this.renderContent();
            this.setupEventListeners();
        } catch (error) {
            console.error('Failed to load historical foundations:', error);
            this.showError('Unable to load historical foundations content. Please check your connection and try again.');
        }
    }
    
    showLoading() {
        if (this.contentContainer) {
            this.contentContainer.innerHTML = Utils.createLoadingHTML();
        }
    }
    
    showError(message) {
        if (this.contentContainer) {
            this.contentContainer.innerHTML = Utils.createErrorHTML(message);
        }
    }
    
    renderBrowseModeSelector() {
        const selectorHTML = `
            <div class="flex gap-4 mb-6 border-b border-gray-200">
                <button id="browse-by-case" class="browse-mode-btn px-4 py-2 font-medium text-gray-700 border-b-2 border-transparent hover:border-purple-500 transition-colors ${this.browseMode === 'case' ? 'active border-purple-600 text-purple-600' : ''}">
                    Browse by Historical Case
                </button>
                <button id="browse-by-theme" class="browse-mode-btn px-4 py-2 font-medium text-gray-700 border-b-2 border-transparent hover:border-purple-500 transition-colors ${this.browseMode === 'theme' ? 'active border-purple-600 text-purple-600' : ''}">
                    Browse by Theme
                </button>
            </div>
        `;
        
        if (!document.getElementById('browse-mode-selector')) {
            const selector = document.createElement('div');
            selector.id = 'browse-mode-selector';
            selector.innerHTML = selectorHTML;
            this.contentContainer.parentNode.insertBefore(selector, this.contentContainer);
        } else {
            document.getElementById('browse-mode-selector').innerHTML = selectorHTML;
        }
        
        document.getElementById('browse-by-case').addEventListener('click', () => {
            this.browseMode = 'case';
            this.closeDetail();
            this.renderBrowseModeSelector();
            this.renderContent();
        });
        
        document.getElementById('browse-by-theme').addEventListener('click', () => {
            this.browseMode = 'theme';
            this.closeDetail();
            this.renderBrowseModeSelector();
            this.renderContent();
        });
    }
    
    setupEventListeners() {
        this.contentContainer.addEventListener('click', (e) => {
            const card = e.target.closest('.historical-card');
            if (card) {
                if (this.browseMode === 'theme') {
                    this.displayThemeDetail(card.dataset.id);
                } else {
                    this.displayCaseDetail(card.dataset.id);
                }
            }
        });
        
        this.contentContainer.addEventListener('keydown', (e) => {
            const card = e.target.closest('.historical-card');
            if (card && (e.key === 'Enter' || e.key === ' ')) {
                e.preventDefault();
                if (this.browseMode === 'theme') {
                    this.displayThemeDetail(card.dataset.id);
                } else {
                    this.displayCaseDetail(card.dataset.id);
                }
            }
        });
        
        document.addEventListener('keydown', (e) => {
            if (e.key === 'Escape' && this.detailContainer.classList.contains('revealed')) {
                this.closeDetail();
            }
        });
    }
    
    /**
     * Format a related protection string with clickable citation link
     * Input: "45 CFR 46.116(b)(9) — Broad consent for storage..."
     * Output: HTML with clickable link for citation and plain text for description
     */
    setupModalListeners() {
        if (!this.modal || !this.modalClose) return;
        
        // Close button click
        this.modalClose.addEventListener('click', () => {
            this.closeModal();
        });
        
        // Click outside modal to close
        this.modal.addEventListener('click', (e) => {
            if (e.target === this.modal) {
                this.closeModal();
            }
        });
        
        // Escape key to close
        document.addEventListener('keydown', (e) => {
            if (e.key === 'Escape' && this.modal.classList.contains('active')) {
                this.closeModal();
            }
        });
        
        // Trap focus within modal when open
        this.modal.addEventListener('keydown', (e) => {
            if (e.key === 'Tab' && this.modal.classList.contains('active')) {
                this.trapFocus(e);
            }
        });
    }
    
    openModal() {
        this.modal.classList.add('active');
        document.body.classList.add('modal-open');
        
        this.lastFocusedElement = document.activeElement;
        
        setTimeout(() => {
            this.modalClose.focus();
        }, 100);
        
        const liveRegion = document.getElementById('live-region');
        if (liveRegion) {
            const title = this.modalBody.querySelector('h2, h3')?.textContent || 'Details opened';
            liveRegion.textContent = title;
        }
    }
    
    closeModal() {
        this.modal.classList.remove('active');
        document.body.classList.remove('modal-open');
        
        document.querySelectorAll('.historical-card').forEach(card => 
            card.classList.remove('selected')
        );
        
        if (this.lastFocusedElement) {
            setTimeout(() => {
                this.lastFocusedElement.focus();
            }, 100);
        }
        
        const liveRegion = document.getElementById('live-region');
        if (liveRegion) {
            liveRegion.textContent = 'Details closed';
        }
    }
    
    trapFocus(e) {
        const focusableElements = this.modal.querySelectorAll(
            'button:not([disabled]), [href], input:not([disabled]), select:not([disabled]), textarea:not([disabled]), [tabindex]:not([tabindex="-1"])'
        );
        const focusable = Array.from(focusableElements);
        const firstFocusable = focusable[0];
        const lastFocusable = focusable[focusable.length - 1];
        
        if (e.shiftKey && document.activeElement === firstFocusable) {
            lastFocusable.focus();
            e.preventDefault();
        } else if (!e.shiftKey && document.activeElement === lastFocusable) {
            firstFocusable.focus();
            e.preventDefault();
        }
    }
    
    formatRelatedProtection(protectionText) {
        // Split by the em dash to separate citation from description
        const parts = protectionText.split(' — ');
        
        if (parts.length < 2) {
            // No description, just return the whole text
            const citation = protectionText.trim();
            const url = this.urls[citation];
            
            if (url) {
                return `<a href="${url}" target="_blank" rel="noopener noreferrer" class="text-blue-600 hover:text-blue-800 hover:underline">${citation}</a>`;
            }
            return citation;
        }
        
        const citation = parts[0].trim();
        const description = parts.slice(1).join(' — ').trim();
        const url = this.urls[citation];
        
        if (url) {
            return `<a href="${url}" target="_blank" rel="noopener noreferrer" class="text-blue-600 hover:text-blue-800 hover:underline">${citation}</a> — ${description}`;
        }
        
        return protectionText;
    }
    
    renderContent() {
        if (this.browseMode === 'theme') {
            this.renderThemeCards();
        } else {
            this.renderCaseCards();
        }
    }
    
    renderThemeCards() {
        const sortedThemes = [...this.data.themes].sort((a, b) => 
            a.title.localeCompare(b.title)
        );
        
        const html = sortedThemes.map(theme => {
            const itemId = `historical-theme-${theme.id}`;
            const isSaved = window.stateManager?.isSaved?.(itemId) || false;
            const starIcon = isSaved ? (window.ICONS?.starFilled || '★') : (window.ICONS?.starOutline || '☆');
            
            return `
            <div class="historical-card bg-gradient-to-br ${theme.gradient} p-4 rounded-xl border-l-4 ${theme.border} shadow-sm cursor-pointer hover:shadow-md transition-shadow" 
                 data-id="${theme.id}"
                 data-item-id="${itemId}"
                 role="button"
                 tabindex="0"
                 aria-label="View details about ${theme.title}">
                <div class="flex items-start justify-between gap-2 mb-2">
                    <h4 class="font-bold text-lg text-gray-900 flex-1">${theme.title}</h4>
                    <button class="theme-star-btn text-lg flex-shrink-0 hover:scale-110 transition-transform" 
                            data-item-id="${itemId}" 
                            data-title="${this.escapeHtml(theme.title)}"
                            title="${isSaved ? 'Unsave theme' : 'Save theme'}"
                            aria-label="${isSaved ? 'Unsave' : 'Save'} ${this.escapeHtml(theme.title)}"
                            onclick="event.stopPropagation();">${starIcon}</button>
                    <button class="ml-1 text-lg flex-shrink-0 hover:scale-110 transition-transform"
                            data-note-btn="true"
                            data-note-id="${itemId}"
                            data-note-type="historical"
                            data-note-label="${this.escapeHtml(theme.title)}"
                            data-note-source="Historical Foundations"
                            title="Add note"
                            onclick="event.stopPropagation();">
                        <span data-note-icon>${window.stateManager?.hasNote && window.stateManager.hasNote(itemId) ? (ICONS.noteFilled || '🖊') : (ICONS.noteOutline || '🖊')}</span>
                    </button>
                </div>
                <p class="text-sm text-gray-700 mb-3">${theme.description}</p>
                <div class="text-xs ${theme.tagColor} font-medium">${theme.ethical_tension}</div>
            </div>
        `;
        }).join('');
        
        this.contentContainer.innerHTML = html;
        this.attachStarListeners();
    }
    
    renderCaseCards() {
        const cases = Object.values(this.data.historical_cases).sort((a, b) => {
            const yearA = parseInt(a.year.split('-')[0]);
            const yearB = parseInt(b.year.split('-')[0]);
            return yearA - yearB;
        });
        
        const html = cases.map(case_ => {
            const itemId = `historical-case-${case_.id}`;
            const isSaved = window.stateManager?.isSaved?.(itemId) || false;
            const starIcon = isSaved ? (window.ICONS?.starFilled || '★') : (window.ICONS?.starOutline || '☆');
            
            return `
            <div class="historical-card bg-white p-4 rounded-xl border-l-4 border-[#008CA8] shadow-sm cursor-pointer hover:shadow-md transition-all" 
                 data-id="${case_.id}"
                 data-item-id="${itemId}"
                 role="button"
                 tabindex="0"
                 aria-label="View details about ${case_.title}">
                <div class="flex items-start justify-between gap-2 mb-2">
                    <div class="flex-1">
                        <div class="flex items-start justify-between mb-2">
                            <h4 class="font-bold text-lg text-gray-900 flex-1">${case_.title}</h4>
                            <span class="text-xs font-semibold text-gray-500 bg-gray-100 px-2 py-1 rounded ml-2">${case_.year}</span>
                        </div>
                    </div>
                    <button class="case-star-btn text-lg flex-shrink-0 hover:scale-110 transition-transform" 
                            data-item-id="${itemId}" 
                            data-title="${this.escapeHtml(case_.title)}"
                            title="${isSaved ? 'Unsave case' : 'Save case'}"
                            aria-label="${isSaved ? 'Unsave' : 'Save'} ${this.escapeHtml(case_.title)}"
                            onclick="event.stopPropagation();">${starIcon}</button>
                    <button class="ml-1 text-lg flex-shrink-0 hover:scale-110 transition-transform"
                            data-note-btn="true"
                            data-note-id="${itemId}"
                            data-note-type="historical"
                            data-note-label="${this.escapeHtml(case_.title)}"
                            data-note-source="Historical Foundations"
                            title="Add note"
                            onclick="event.stopPropagation();">
                        <span data-note-icon>${window.stateManager?.hasNote && window.stateManager.hasNote(itemId) ? (ICONS.noteFilled || '🖊') : (ICONS.noteOutline || '🖊')}</span>
                    </button>
                </div>
                <p class="text-sm text-gray-700 line-clamp-2">${case_.what_happened}</p>
            </div>
        `;
        }).join('');
        
        this.contentContainer.innerHTML = html;
        this.attachStarListeners();
    }
    
    displayThemeDetail(themeId) {
        document.querySelectorAll('.historical-card').forEach(card => 
            card.classList.remove('selected')
        );
        
        const selectedCard = document.querySelector(`[data-id="${themeId}"]`);
        if (selectedCard) {
            selectedCard.classList.add('selected');
        }
        
        const theme = this.data.themes.find(t => t.id === themeId);
        if (!theme) return;
        
        const primaryCase = this.data.historical_cases[theme.primary_case];
        const relatedCases = theme.related_cases.map(caseId => 
            this.data.historical_cases[caseId]
        ).filter(c => c);

        // --- START MODIFICATION ---
        const itemId = `historical-theme-${theme.id}`;
        const isSaved = window.stateManager?.isSaved?.(itemId) || false;
        const hasNote = window.stateManager?.hasNote?.(itemId) || false;
        const starIcon = isSaved ? (window.ICONS?.starFilled || '★') : (window.ICONS?.starOutline || '☆');
        const noteIcon = hasNote ? (window.ICONS?.noteFilled || '🖊') : (window.ICONS?.noteOutline || '🖊');
        const safeTitle = this.escapeHtml(theme.title);

        // Corrected size (text-lg) and hover color (hover:text-gray-900)
        const buttonHTML = `
            <div class="flex items-center gap-2 flex-shrink-0 absolute top-5 right-20" style="top: 20px; right: 80px;">
                <button class="theme-star-btn text-lg hover:text-gray-900 hover:scale-110 transition-transform" 
                        data-item-id="${itemId}" 
                        data-title="${safeTitle}"
                        title="${isSaved ? 'Unsave theme' : 'Save theme'}"
                        aria-label="${isSaved ? 'Unsave' : 'Save'} ${safeTitle}">
                    ${starIcon}
                </button>
                <button class="ml-1 text-lg hover:text-gray-900 hover:scale-110 transition-transform"
                        data-note-btn="true"
                        data-note-id="${itemId}"
                        data-note-type="historical"
                        data-note-label="${safeTitle}"
                        data-note-source="Historical Foundations"
                        title="${hasNote ? 'Edit note' : 'Add note'}">
                    <span data-note-icon>${noteIcon}</span>
                </button>
            </div>
        `;
        // --- END MODIFICATION ---
        
        const html = `
            ${buttonHTML} 
            <h2 id="historical-modal-title" class="text-2xl font-bold text-gray-900 mb-4 pr-24">${theme.title}</h2> 
            
            <div class="bg-blue-50 border-l-4 border-blue-500 p-4 rounded mb-6">
                <p class="text-blue-800 text-sm mb-2">${theme.description}</p>
                <p class="text-blue-700 text-xs font-medium italic">${theme.ethical_tension}</p>
            </div>
            
            <h3 class="text-lg font-semibold text-gray-800 mb-3">Key Historical Case</h3>
            ${this.renderInteractiveCaseCard(primaryCase, true)}
            
            ${relatedCases.length > 0 ? `
                <h3 class="text-lg font-semibold text-gray-800 mb-3 mt-6">Related Cases</h3>
                ${relatedCases.map(case_ => this.renderInteractiveCaseCard(case_, true)).join('')}
            ` : ''}
        `;
        
        this.modalBody.innerHTML = html;
        this.openModal();
        this.setupProblemClickHandlers();
        this.attachModalStarListener(itemId, safeTitle, 'historical-theme');
    }
    
    displayCaseDetail(caseId) {
        document.querySelectorAll('.historical-card').forEach(card => 
            card.classList.remove('selected')
        );
        
        const selectedCard = document.querySelector(`[data-id="${caseId}"]`);
        if (selectedCard) {
            selectedCard.classList.add('selected');
        }
        
        const case_ = this.data.historical_cases[caseId];
        if (!case_) return;
        
        // --- START MODIFICATION ---
        const itemId = `historical-case-${case_.id}`;
        const isSaved = window.stateManager?.isSaved?.(itemId) || false;
        const hasNote = window.stateManager?.hasNote?.(itemId) || false;
        const starIcon = isSaved ? (window.ICONS?.starFilled || '★') : (window.ICONS?.starOutline || '☆');
        const noteIcon = hasNote ? (window.ICONS?.noteFilled || '🖊') : (window.ICONS?.noteOutline || '🖊');
        const safeTitle = this.escapeHtml(case_.title);

        // Corrected button HTML (size and color) and placement (absolute)
        const buttonHTML = `
            <div class="flex items-center gap-2 flex-shrink-0 absolute top-5 right-20" style="top: 20px; right: 80px;">
                <button class="case-star-btn text-lg hover:text-gray-900 hover:scale-110 transition-transform" 
                        data-item-id="${itemId}" 
                        data-title="${safeTitle}"
                        title="${isSaved ? 'Unsave case' : 'Save case'}"
                        aria-label="${isSaved ? 'Unsave' : 'Save'} ${safeTitle}">
                    ${starIcon}
                </button>
                <button class="ml-1 text-lg hover:text-gray-900 hover:scale-110 transition-transform"
                        data-note-btn="true"
                        data-note-id="${itemId}"
                        data-note-type="historical"
                        data-note-label="${safeTitle}"
                        data-note-source="Historical Foundations"
                        title="${hasNote ? 'Edit note' : 'Add note'}">
                    <span data-note-icon>${noteIcon}</span>
                </button>
            </div>
        `;
        
        // Corrected layout: added buttons, added pr-24 to title's PARENT, moved year next to title
        const html = `
            ${buttonHTML}
            <div class="mb-6 pr-24">
                <div class="flex items-center gap-3 mb-1">
                    <h2 id="historical-modal-title" class="text-2xl font-bold text-gray-900 min-w-0">${case_.title}</h2>
                    <span class="text-sm font-semibold text-gray-600 bg-gray-100 px-3 py-1 rounded whitespace-nowrap">${case_.year}</span>
                </div>
            </div>
            
            ${this.renderInteractiveCaseCard(case_, false)}
        `;
        // --- END MODIFICATION ---
        
        this.modalBody.innerHTML = html;
        this.openModal();
        this.setupProblemClickHandlers();
        this.attachModalStarListener(itemId, safeTitle, 'historical-case');
    }
    
    renderInteractiveCaseCard(case_, showTitle) {
        // Retrieve the custom warning icon for problem items.  If it
        // isn't defined, fall back to a simple exclamation mark.
        const wrongIcon = (window.ICONS && window.ICONS.wrong) || '!';
        return `
            <div class="bg-white border border-gray-200 rounded-lg p-4 mb-4 case-detail-card" data-case-id="${case_.id}">
                ${showTitle ? `
                    <div class="flex items-start justify-between mb-2">
                        <h4 class="font-bold text-gray-900">${case_.title}</h4>
                        <span class="text-xs font-semibold text-gray-500 bg-gray-100 px-2 py-1 rounded">${case_.year}</span>
                    </div>
                ` : ''}
                <p class="text-sm text-gray-700 mb-4">${case_.what_happened}</p>
                
                <div class="mb-4">
                    <h5 class="font-semibold text-red-700 mb-3">What Went Wrong</h5>
                    <div class="space-y-2">
                        ${case_.what_went_wrong.map((problem, idx) => `
                            <div class="problem-card bg-gradient-to-r from-red-50 to-pink-50 border-l-4 border-red-500 p-3 rounded cursor-pointer hover:shadow-md transition-all duration-200" 
                                 data-problem-idx="${idx}"
                                 data-case-id="${case_.id}"
                                 role="button"
                                 tabindex="0"
                                 aria-label="Explore issue: ${problem}">
                                <div class="problem-text text-sm text-red-900 flex items-start gap-2">
                                    <span class="text-orange-500">${wrongIcon}</span>
                                    <span>${problem}</span>
                                </div>
                            </div>
                        `).join('')}
                    </div>
                </div>
                
                <div id="lessons-panel-${case_.id}" class="lessons-panel hidden"></div>
            </div>
        `;
    }
    
    setupProblemClickHandlers() {
        document.querySelectorAll('.problem-card').forEach(card => {
            card.addEventListener('click', (e) => {
                const caseId = e.currentTarget.dataset.caseId;
                const problemIdx = parseInt(e.currentTarget.dataset.problemIdx);
                this.showLessonsForProblem(caseId, problemIdx, e.currentTarget);
            });
            
            card.addEventListener('keydown', (e) => {
                if (e.key === 'Enter' || e.key === ' ') {
                    e.preventDefault();
                    const caseId = e.currentTarget.dataset.caseId;
                    const problemIdx = parseInt(e.currentTarget.dataset.problemIdx);
                    this.showLessonsForProblem(caseId, problemIdx, e.currentTarget);
                }
            });
        });
    }

    // ADD THIS NEW METHOD
    attachModalStarListener(itemId, title, itemType) {
        const starBtn = this.modalBody.querySelector(`.case-star-btn[data-item-id="${CSS.escape(itemId)}"], .theme-star-btn[data-item-id="${CSS.escape(itemId)}"]`);
        if (!starBtn) return;

        starBtn.addEventListener('click', (e) => {
            e.preventDefault();
            e.stopPropagation();
            
            if (window.stateManager) {
                const isCurrentlySaved = window.stateManager.isSaved(itemId);
                window.stateManager.toggleSaved(itemId, {
                    type: itemType,
                    title: title,
                    tab: 'historical'
                });
                
                // Update button UI *in the modal*
                const isSaved = !isCurrentlySaved;
                const starIcon = isSaved ? (window.ICONS?.starFilled || '★') : (window.ICONS?.starOutline || '☆');
                starBtn.innerHTML = starIcon;
                const typeLabel = itemType === 'historical-case' ? 'case' : 'theme';
                starBtn.setAttribute('title', isSaved ? `Unsave ${typeLabel}` : `Save ${typeLabel}`);
                starBtn.setAttribute('aria-label', `${isSaved ? 'Unsave' : 'Save'} ${title}`);

                // Also update the star on the card *outside* the modal
                const cardStarBtn = this.contentContainer.querySelector(`[data-item-id="${CSS.escape(itemId)}"] .case-star-btn, [data-item-id="${CSS.escape(itemId)}"] .theme-star-btn`);
                if (cardStarBtn) {
                    cardStarBtn.innerHTML = starIcon;
                    cardStarBtn.setAttribute('title', isSaved ? `Unsave ${typeLabel}` : `Save ${typeLabel}`);
                    cardStarBtn.setAttribute('aria-label', `${isSaved ? 'Unsave' : 'Save'} ${title}`);
                }
            }
        });
    }
    
    showLessonsForProblem(caseId, problemIdx, problemCard) {
        const case_ = this.data.historical_cases[caseId];
        if (!case_) return;
        
        const caseCard = problemCard.closest('.case-detail-card');
        caseCard.querySelectorAll('.problem-card').forEach(card => {
            card.classList.remove('selected-problem');
        });
        
        problemCard.classList.add('selected-problem');
        
        const connections = this.caseConnections[caseId];
        const problemConnections = connections ? connections[problemIdx] : null;
        const panel = document.getElementById(`lessons-panel-${caseId}`);
        
        const relevantLessons = problemConnections ? problemConnections.lessons.map(idx => case_.what_we_learned[idx]) : case_.what_we_learned;
        const relevantRegulations = problemConnections ? problemConnections.regulations.map(idx => case_.related_protections[idx]) : case_.related_protections;

        // Pull icons from the global ICONS object.  If the icon
        // definitions are not present for some reason, fall back to
        // empty strings so no stray text appears.  These icons are
        // used to replace the emoji in the panel below.
        const lessonsIcon = (window.ICONS && window.ICONS.lessons) || '';
        const protectionsIcon = (window.ICONS && window.ICONS.protections) || '';
        const checkIcon = (window.ICONS && window.ICONS.check) || '';

        panel.innerHTML = `
            <div class="bg-gradient-to-r from-purple-50 to-indigo-50 border-2 border-purple-300 rounded-lg p-4 animate-slideIn">
                <div class="flex items-start gap-3 mb-4">
                    <div class="text-2xl text-green-600">${lessonsIcon}</div>
                    <div class="flex-1">
                        <h5 class="font-bold text-green-800 mb-2">What We Learned</h5>
                        <ul class="space-y-2">
                            ${relevantLessons.map(lesson => `
                                <li class="text-sm text-green-700 flex items-start gap-2">
                                    <span class="text-green-600 font-bold text-base inline-flex items-center">${checkIcon}</span>
                                    <span>${lesson}</span>
                                </li>
                            `).join('')}
                        </ul>
                    </div>
                </div>
                
                <div class="flex items-start gap-3 pt-4 border-t border-purple-200">
                    <div class="text-2xl text-blue-600">${protectionsIcon}</div>
                    <div class="flex-1">
                        <h5 class="font-bold text-blue-800 mb-2">Related Protections</h5>
                        <div class="space-y-2">
                            ${relevantRegulations.map(reg => `
                                <div class="text-sm pl-2">${this.formatRelatedProtection(reg)}</div>
                            `).join('')}
                        </div>
                    </div>
                </div>
                
                <div class_alias="mt-4 pt-4 border-t border-purple-200 text-center">
                    <button class="close-lessons-btn p-2 rounded flex items-center justify-center mx-auto text-gray-500 border border-transparent hover:border-gray-300 hover:bg-gray-100 hover:text-gray-700 text-2xl leading-none" aria-label="Close panel">
                        ${ (window.ICONS && window.ICONS.cross) || '&times;' }
                    </button>
                </div>
            </div>
        `;
        
        panel.classList.remove('hidden');
        panel.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
        
        // Enhance citation links with read/star functionality
        if (window.linkEnhancer) {
            const citationLinks = panel.querySelectorAll('a[href]');
            citationLinks.forEach(link => {
                // Get the full text of the parent to extract description
                const parentText = link.parentElement?.textContent || '';
                const linkText = link.textContent.trim();
                // Extract description after " — "
                const descMatch = parentText.match(new RegExp(linkText.replace(/[.*+?^${}()|[\]\\]/g, '\\$&') + '\\s*—\\s*(.+)'));
                const description = descMatch ? descMatch[1].trim() : '';
                
                const context = {
                    type: 'historical-case',
                    title: linkText,
                    source: `Historical: ${case_.title || case_.name}`,
                    description: description
                };
                window.linkEnhancer.enhanceLink(link, context);
            });
        }
        
        panel.querySelector('.close-lessons-btn').addEventListener('click', () => {
            panel.classList.add('hidden');
            problemCard.classList.remove('selected-problem');
        });
    }
    
    closeDetail() {
        this.detailContainer.classList.remove('revealed');
        document.querySelectorAll('.historical-card').forEach(card => 
            card.classList.remove('selected')
        );
    }
    
    attachStarListeners() {
        const starButtons = this.contentContainer.querySelectorAll('.theme-star-btn, .case-star-btn');
        starButtons.forEach(btn => {
            btn.addEventListener('click', (e) => {
                e.preventDefault();
                e.stopPropagation();
                const itemId = btn.dataset.itemId;
                const title = btn.dataset.title;
                const isTheme = btn.classList.contains('theme-star-btn');
                
                if (window.stateManager) {
                    const isCurrentlySaved = window.stateManager.isSaved(itemId);
                    const context = {
                        type: isTheme ? 'historical-theme' : 'historical-case',
                        title: title,
                        tab: 'historical'
                    };
                    window.stateManager.toggleSaved(itemId, context);
                    
                    // Update button UI
                    const isSaved = !isCurrentlySaved;
                    const starIcon = isSaved ? (window.ICONS?.starFilled || '★') : (window.ICONS?.starOutline || '☆');
                    btn.innerHTML = starIcon;
                    btn.setAttribute('title', isSaved ? `Unsave ${isTheme ? 'theme' : 'case'}` : `Save ${isTheme ? 'theme' : 'case'}`);
                    btn.setAttribute('aria-label', `${isSaved ? 'Unsave' : 'Save'} ${title}`);
                }
            });
        });
    }
    
    escapeHtml(str) {
        const div = document.createElement('div');
        div.textContent = str;
        return div.innerHTML;
    }
}

window.HistoricalManager = HistoricalManager;